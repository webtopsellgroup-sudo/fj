import React from 'react';
import CommitmentForm from './components/CommitmentForm';

function App() {
  return <CommitmentForm />;
}

export default App;